import React, { useState } from 'react';
import { v1 } from 'uuid';
import './App.css';
import { TaskType, TodoList } from './components/todoList'
import { V1Options } from 'uuid';

import { Rating } from './Rating';



export type FilterValuesType = 'all' | 'completed' | 'active'

function App() {




  let [tasks, setTask] = useState<Array<TaskType>>([
    { id: v1(), title: "CSS", isDone: true },
    { id: v1(), title: "JS", isDone: true },
    { id: v1(), title: "REact", isDone: false },
    { id: v1(), title: "REdux", isDone: false},
    { id: v1(), title: "HTML", isDone: true },
    { id: v1(), title: "Node", isDone: false},
    { id: v1(), title: "Mongo", isDone: false},
    { id: v1(), title: "Express", isDone: true},
    { id: v1(), title: "React", isDone: true},
    { id: v1(), title: "Redux", isDone: false},
  ])


   
  



  function removeTask(id: string) {

    let filteredTasks = tasks.filter(t => t.id !== id)
    setTask(filteredTasks)
  }
function addTask(title:string){
  let newTask = {id: v1(),title:title,isDone:false}
  let newTasks = [newTask,...tasks]
  setTask(newTasks)
  
}
function changeStatus(taskId:string,isDone:boolean){
   let task = tasks.find(t => t.id === taskId)
   if(task){
    task.isDone = isDone
   }
   setTask(tasks)
}

  function changeFilter(value:FilterValuesType){
    setFilter(value);
  }



  let [filter, setFilter] = useState<FilterValuesType>('all')


  let tasksForTodoList = tasks
  if (filter === 'completed') {
    tasksForTodoList = tasks.filter(t => t.isDone === true)
  }
  if (filter === 'active') {
    tasksForTodoList = tasks.filter(t => t.isDone === false)
  }

  return (
    <div className='App'>

      <TodoList title='What to learn' 
      tasks={tasksForTodoList} 
      removeTask={removeTask}
      changeFilter={changeFilter}
      addTask = {addTask}
      
      
      />,


      <input type='checkbox' />,
      <input type='date' />,
      <input placeholder='it-incubator' />,



    </div>
    
  );
 
}




export default App;