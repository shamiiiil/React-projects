import React from "react";
export function Rating (){
    console.log('Rating rendering...')
    return (
        <div className="star">
            <Star/>,
            <Star/>,
            <Star/>,
            <Star/>
        </div>

    )

}
function Star (props:any){
    return (
        <span><b>star</b></span>
    )
}